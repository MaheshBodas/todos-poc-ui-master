export default {
  container: {       
      height: '500px',
      border: '1px'
    },
    main: {       
      height: '350px',
      border: '1px'
    },
    formselectriskinstance : {
      flex:1,
      align: 'left',
      marginLeft: '5px'
     }
}
