export default {
    dashboardLabel:{
        fontSize: '15px',
        fontWeight: 'bold',
        opacity: '0.75',
        lineHeight: '20px',
        margin: 0,
        textAlign: 'right',        
        color: '#0000ff'
     },
     helpTextLabel:{
        fontSize: '15px',  
        fontWeight: 'bold',      
        opacity: '0.75',
        lineHeight: '20px',
        margin: 0,
        textAlign: 'left',        
        color: '#0000ff'
     }
  }