export class DashboardConst {
}
DashboardConst.CarouselHelpText = [
  {
    'id': 1,
    'text': 'Admin user can use Create Risk [ Risk Type ]  screen to define RiskTypes.'
  },
  {
    'id': 2,
    'text': 'Use Create Risk [ Risk Instance ] screen to add Risk Instances based on RiskTypes.'
  },
  {
    'id': 3,
    'text': 'Use View Risk [ Single Risk ] screen to view single Risk.'
  },
  {
    'id': 4,
    'text': 'Use View Risk [ All Risk ] screen to view all Risks.'
  }
]
